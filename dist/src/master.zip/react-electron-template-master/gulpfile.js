const gulp = require("gulp");
const pkg = require("./package.json");
const yaml = require("js-yaml");

const { createHash } = require("crypto");
const fs = require("fs");
let yamlPath = "build";
const jsonPath = "build/latest.json";

const fileName = `${pkg.build.productName} Setup ${pkg.version}.exe`;

function hashFile(file, algorithm = "sha512", encoding = "base64", options) {
  const size = fs.statSync(file).size;
  return new Promise((resolve, reject) => {
    const hash = createHash(algorithm);
    hash.on("error", reject).setEncoding(encoding);

    fs.createReadStream(file, { ...options, highWaterMark: 1024 * 1024 })
      .on("error", reject)
      .on("end", () => {
        hash.end();
        resolve({
          size,
          sha512: hash.read(),
        });
      })
      .pipe(hash, { end: false });
  });
}

gulp.task("hash:write", (cb) => {
  hashFile(`build/${fileName}`).then((res) => {
    fs.readdir("build", function (err, files) {
      files.forEach((item) => {
        const reg = /(\w)*\.yml/;
        if (reg.test(item)) {
          const originYamlPath = yamlPath + "/" + item;
          let latest = yaml.safeLoad(fs.readFileSync(originYamlPath, "utf8"));
          latest.version = pkg.version;
          latest.files[0].url = fileName;
          latest.files[0].sha512 = res.sha512;
          latest.files[0].size = res.size;
          latest.path = fileName;
          latest.sha512 = res.sha512;
          latest.releaseDate = new Date().toISOString();
          let latestYaml = yaml.safeDump(latest, {
            lineWidth: 8000,
          });
          const destYamlPath = yamlPath + "/" + "latest.yml";
          fs.writeFileSync(destYamlPath, latestYaml, "utf8");
          fs.writeFileSync(jsonPath, JSON.stringify(latest, "", "  "), "utf8");
          cb();
          console.log("Dump success with version", pkg.version);
        }
      });
    });
  });
});

gulp.task("hash:write-mac", (cb) => {
  const fileName = `${pkg.build.productName} Setup ${pkg.version}.dmg`;
  hashFile(`build/${fileName}`).then(() => {
    const latest = yaml.safeLoad(
      fs.readFileSync("build/latest-mac.yml", "utf8")
    );

    const data = {
      version: latest.version,
      files: [
        {
          url: latest.files[1].url,
          sha512: latest.files[1].sha512,
          size: latest.files[1].size,
        },
      ],
      path: latest.files[1].url,
      sha512: latest.files[1].sha512,
      releaseDate: latest.releaseDate,
    };

    fs.writeFileSync(jsonPath, JSON.stringify(data, "", "  "), "utf8");
    cb();
  });
});
