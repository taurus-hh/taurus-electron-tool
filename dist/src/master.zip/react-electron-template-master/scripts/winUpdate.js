const yaml = require("js-yaml");
const fs = require("fs");
const os = require("os");
exports.default = function () {
  if (os.platform() === "darwin") return false;
  try {
    const docYml = {
      provider: "generic",
      url:
        "https://courseware-dev-1302600247.cos.ap-beijing.myqcloud.com/jiaoyanyun/win32-stage",
      publishAutoUpdate: true,
      updaterCacheDirName: "cactus-elecboard-updater",
    };
    let destYamlPath = "build/win-ia32-unpacked/resources/app-update.yml";
    switch (process.env.API_ENV) {
      case "staging": // 仿真
        docYml.url =
          "https://courseware-dev-1302600247.cos.ap-beijing.myqcloud.com/jiaoyanyun/win32-stage";

        break;
      case "prerelease": // 预发布
        docYml.url =
          "https://courseware-dev-1302600247.cos.ap-beijing.myqcloud.com/jiaoyanyun/win32-stage";
        break;
      case "production":
        docYml.url =
          "https://courseware-1302600247.cos.ap-beijing.myqcloud.com/jiaoyanyun/win32";
        break;
      default:
        console.log("default---");
    }
    let winYaml = yaml.safeDump(docYml, {
      lineWidth: 8000,
    });
    fs.writeFileSync(destYamlPath, winYaml, "utf8");
  } catch (e) {
    console.log(e);
  }
};
