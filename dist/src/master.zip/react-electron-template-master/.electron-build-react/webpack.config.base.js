const path = require('path');
const { dependencies } = require('../package.json');

exports.default = {
  mode: 'development',
  externals: [...Object.keys(dependencies || {})],
  module: {
    rules: [
      {
        test: /\.tsx?$/,
        loader: 'babel-loader',
      },
    ]
  },

  output: {
    filename: '[name].js',
    path: path.join(__dirname, '../dist/electron'),
  },

  resolve: {
    extensions: ['.ts', '.tsx', '.js'],
  },

  node: {
    __filename: false,
    __dirname: false
  },
};
