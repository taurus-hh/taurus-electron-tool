process.env.NODE_ENV = 'production';

const { say } = require('cfonts');
const chalk = require('chalk');
const del = require('del');

const webpack = require('webpack');
const Spinnies = require('spinnies');

const mainConfig = require('./webpack.config.main');
const rendererConfig = require('./webpack.config.prod.render');


const doneLog = chalk.bgGreen.white(' DONE ') + ' '
const errorLog = chalk.bgRed.white(' ERROR ') + ' '
const okayLog = chalk.bgBlue.white(' OKAY ') + ' '



/**
 * @description: 清理pack后的构建包应用
 * @msg:
 * @param {*}
 * @return {*}
 */
function cleanBuild () {
  del.sync(['build/*', '!build/icons', '!build/icons/icon.*'])
  console.log(`\n${doneLog}\n`)
  process.exit()
}
let task

/**
 * @description: 打包主进程和渲染进程
 * @msg:
 * @param {*}
 * @return {*}
 */
function buildApp () {
  greeting()
  // 删除之前构建文件
  del.sync(['dist/electron/*', '!.gitkeep']);

  const spinner = { interval: 80, frames: ['🍇', '🍈', '🍉', '🍋'] }
  task = new Spinnies({
    color: 'blue',
    succeedColor:'green',
    failColor: "red",
    spinner
  })
  task.add('Main', { text: 'building main process \n' })
  task.add('Renderer', { text: 'building render process \n' })

  let results = ''
  packApp(mainConfig).then(result => {
    results += result + '\n\n'
    logStats(result, "Main")
  }).catch(err => {
    task.fail('Main', { text: "Main Process Fail!"})
    console.log(`\n  ${errorLog}failed to build main process`)
    console.error(`\n${err}\n`)
    process.exit()
  })

  packApp(rendererConfig).then(result => {
    results += result + '\n\n'
    logStats(result, "Renderer")
  }).catch(err => {
    task.fail('Renderer', { text: "Renderer Process Fail!"})
    console.log(`\n  ${errorLog}failed to build renderer process`)
    console.error(`\n${err}\n`)
    process.exit()
  })
}

/**
 * @description: webpack生产环境构建
 */
function packApp (config) {
  return new Promise((resolve, reject) => {
    config.mode = 'production'
    config.devtool = 'source-map'
    webpack(config, (err, stats) => {
      if (err) reject(err.stack || err)
      else if (stats.hasErrors()) {
        let err = ''
        stats.toString({
          chunks: false,
          colors: true
        })
        .split(/\r?\n/)
        .forEach(line => {
          err += `    ${line}\n`
        })
        reject(err)
      } else {
        resolve(stats.toString({
          chunks: false,
          colors: true
        }))
      }
    })
  })
}

/**
 * @description: teminal greenting
 * @msg:
 * @param {*}
 * @return {*}
 */
function greeting () {
  const cols = process.stdout.columns
  let text = ''

  if (cols > 85) text = 'lets-build'
  else if (cols > 60) text = 'lets-|build'
  else text = false

  if (text) {
    say(text, {
      colors: ['yellow'],
      font: 'simple3d',
      space: false
    })
  } else console.log(chalk.yellow.bold('\n  lets-build'))
  console.log()
}

/**
 * @description: 输出构建结果
 * @msg:
 */
function logStats(results, processName) {
  task.succeed(processName, { text: `${processName} Process Sucess!`})
  process.stdout.write('\x1B[2J\x1B[0f')
  console.log(`\n\n${results}`)
  console.log(`${okayLog}take it away ${chalk.yellow('`electron-builder`')}\n`)
}
buildApp()
