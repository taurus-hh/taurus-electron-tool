const path = require('path');
const webpack = require('webpack');
const { merge }= require('webpack-merge');
const baseConfig = require('./webpack.config.base');
const htmlWebpackPlugin = require('html-webpack-plugin');
const MiniCssExtractPlugin = require('mini-css-extract-plugin');
const CopyPlugin = require("copy-webpack-plugin");
const OptimizeCSSAssetsPlugin = require('optimize-css-assets-webpack-plugin');

module.exports = merge(baseConfig.default, {
  devtool: "source-map",
  entry: {
    'renderer': path.resolve(__dirname, '../src/renderer-process/index.tsx'),
  },
  output: {
    filename: '[name].js',
    path: path.resolve(__dirname, '../dist/electron'),
    publicPath: '',
    libraryTarget: 'commonjs2',
  },
  module: {
    rules: [
      {
        test: /\.css$/,
        use: [
          {
            loader: MiniCssExtractPlugin.loader
          },
          {
            loader: "css-loader"
          },
        ],
      },
      {
        test: /\.less$/,
        use: [
          {
            loader: MiniCssExtractPlugin.loader
          },
          {
            loader: "css-loader"
          },
          {
            loader: "less-loader",
            options: {
              lessOptions: {
                javascriptEnabled: true
              }
            }
          }
        ]
      },
      {
        test: /\.(png|jpg|gif|jpeg)$/,
        use: [
          {
            loader: 'url-loader',
            options: {
              limit: 8192,
              esModule: false,
            },
          }
        ]
      }
    ]
  },
  plugins: [
    new htmlWebpackPlugin(
      {
        template: 'src/index.ejs',
        nodeModules: path.resolve(__dirname, '../node_modules')
      }
    ),
    new CopyPlugin({
      patterns: [
        { from: path.join(__dirname, '../static'), to: path.join(__dirname, '../dist/electron/static') },
      ],
    }),
    new webpack.DefinePlugin({
      "NODE_ENV": JSON.stringify(process.env.NODE_ENV),
      "API_ENV": JSON.stringify(process.env.API_ENV)
    }),
    new MiniCssExtractPlugin({
      filename: 'style.css'
    }),
    new OptimizeCSSAssetsPlugin({
      assetNameRegExp: /\.optimize\.css$/g,
      cssProcessor: require('cssnano'),
      cssProcessorPluginOptions: {
        preset: ['default', { discardComments: { removeAll: true } }],
      },
      canPrint: true
    })
  ],
  target: 'electron-renderer',
  resolve: {
    alias: {
      '@': path.join(__dirname, '../src/renderer-process')
    },
  },
});
