process.env.NODE_ENV = "development";

const webpack = require('webpack');
const webpackDevServer = require('webpack-dev-server');
const rendererConfig = require('./webpack.config.render');
const mainConfig = require('./webpack.config.main');

const { spawn } = require('child_process');
const { say } = require('cfonts')
const electron = require('electron');
const path = require('path');
const chalk = require('chalk');

let electronProcess = null
let manualRestart = false

/**
 * @description: 编译渲染进程
 * @msg:
 * @param {*}
 * @return {*} promise
 */
async function startRender() {
  return new Promise((resolve, reject) => {
    const compilerRenderer = webpack(rendererConfig)
    const devServerOptions = Object.assign({},{
      stats: {
        colors: true,
      },
      contentBase: path.join(__dirname, "../static/"),
      before(app, ctx) {
        ctx.middleware.waitUntilValid(() => {
          resolve()
        })
      }
    });
    const server = new webpackDevServer(compilerRenderer, devServerOptions);
    server.listen('8081', '127.0.0.1', () => {
      console.log('Starting server on http://localhost:' + 8081);
    });
  })
}

/**
 * @description: 编译主进程
 * @msg:
 * @param {*}
 * @return {*} promise
 */
async function startMain() {
  return new Promise((resolve) => {
    const compiler = webpack(mainConfig)
    compiler.hooks.watchRun.tapAsync('watch-run', (compilation, done) => {
      done()
    })
    compiler.watch({}, (err, stats) => {
      if (err) {
        console.log(err)
        return
      }
      if (electronProcess && electronProcess.kill) {
        manualRestart = true
        process.kill(electronProcess.pid)
        electronProcess = null
        startElectron()

        setTimeout(() => {
          manualRestart = false
        }, 5000)
      }
      resolve()
    })
  })
}

/**
 * @description: 启动electron子进程
 * @msg:
 * @param {*}
 * @return {*} promise
 */
async function startElectron() {
  var args = [
    '--inspect=5858',
    path.join(__dirname, '../dist/electron/main.js')
  ]

  if (process.env.npm_execpath.endsWith('yarn.js')) {
    args = args.concat(process.argv.slice(3))
  } else if (process.env.npm_execpath.endsWith('npm-cli.js')) {
    args = args.concat(process.argv.slice(2))
  }
  electronProcess = spawn(electron, args)

  electronProcess.stdout.on('data', data => {
    electronLog(data, 'blue')
  })
  electronProcess.stderr.on('data', data => {
    electronLog(data, 'red')
  })

  electronProcess.on('close', () => {
    if (!manualRestart) process.exit()
  })
}

/**
 * @description: 打印子进程的log信息
 * @msg:
 * @param {*}
 * @return {*}
 */
function electronLog(data, color) {
  let log = ''
  data = data.toString().split(/\r?\n/)
  data.forEach(line => {
    log += `  ${line}\n`
  })
  if (/[0-9A-z]+/.test(log)) {
    console.log(
      chalk[color].bold('┏ Electron -------------------') +
      '\n\n' +
      log +
      chalk[color].bold('┗ ----------------------------') +
      '\n'
    )
  }
}
/**
 * @description: greeting project
 */
function greeting () {
  const cols = process.stdout.columns
  let text = ''

  if (cols > 104) text = 'electron-react'
  else if (cols > 76) text = 'electron-|react'
  else text = false

  if (text) {
    say(text, {
      colors: ['green'],
      gradient: ['cyan', 'red'],
      font: 'simple3d',
      space: false,
      align: "center"
    })
  } else console.log(chalk.green.bold('\n  electron-react'))
  console.log(chalk.blue.bold('  getting ready...') + '\n')
}
/**
 * @description: 启动应用
 */
(async function startApp() {
  try {
    greeting()
    await Promise.all([startRender(), startMain()])
    startElectron()
  } catch (error) {
    console.log(error)
  }
}())
