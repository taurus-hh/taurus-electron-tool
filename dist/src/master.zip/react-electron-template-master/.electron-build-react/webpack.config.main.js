const path = require('path');
const webpack = require('webpack');
const { merge } = require('webpack-merge');
const baseConfig = require('./webpack.config.base');

module.exports = merge(baseConfig.default, {
  devtool: "inline-source-map",
  entry: {
    'main': path.resolve(__dirname, '../src/main-process/index.ts'),
    'unzip': path.resolve(__dirname, '../src/main-process/unzip/unzip.ts'),
  },
  output: {
    libraryTarget: 'commonjs2'
  },
  plugins: [
    new webpack.DefinePlugin({
      "NODE_ENV": JSON.stringify(process.env.NODE_ENV),
      "API_ENV": JSON.stringify(process.env.API_ENV)
    }),
  ],
  target: 'electron-main',
});
