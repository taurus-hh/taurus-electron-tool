window.module = module;
window.require = require;
