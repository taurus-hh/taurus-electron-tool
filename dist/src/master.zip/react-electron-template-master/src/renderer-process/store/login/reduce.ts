import { LoginActions, LoginActionTypes } from "./types";
const initState = [];
function login(state = initState, action: LoginActions) {
  switch (action.type) {
    case LoginActionTypes.LoginAuth:
      return state;
    case LoginActionTypes.LoginSuccess:
      return state;
    default:
      return state;
  }
}
export default login;
