import { AnyAction } from "redux";
export enum LoginActionTypes {
  LoginAuth = "LOGIN/AUTH",
  LoginSuccess = "LOGIN/SUCCESS",
  LoginFail = "LOGIN/Fail",
}
export interface LoginAuthAction extends AnyAction {
  type: LoginActionTypes.LoginAuth;
  payload: { id: string; spell?: string };
}
export interface LoginSuccessAction extends AnyAction {
  type: LoginActionTypes.LoginSuccess;
  payload: { id: string };
}
export type LoginActions = LoginAuthAction | LoginSuccessAction;
