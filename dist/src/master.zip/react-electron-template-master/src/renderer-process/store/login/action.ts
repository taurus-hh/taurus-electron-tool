import { Dispatch } from "redux";
import { LoginActionTypes, LoginActions } from "./types";
export function loginAuth(params) {
  return (dispatch: Dispatch<LoginActions>) => {
    console.log(params);
    dispatch({ type: LoginActionTypes.LoginAuth, payload: { id: "yzx" } });
  };
}
