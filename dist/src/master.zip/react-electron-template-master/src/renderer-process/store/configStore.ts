import {
  applyMiddleware,
  compose,
  createStore,
  bindActionCreators,
} from "redux";
import { connect } from "react-redux";
import rootReducer from "./rootReducers";
import middlewares from "./middleware/index";
import { composeWithDevTools } from "redux-devtools-extension";
// 配置store 函数
export function configStore(preloadedState) {
  const middlewareEnhancers = applyMiddleware(...middlewares);
  const enhancers = [middlewareEnhancers];
  const composedEnhancers = composeWithDevTools(compose(...enhancers));
  const store = createStore(rootReducer, preloadedState, composedEnhancers);
  return store;
}
// 配置connect 函数
export function configConnect(stateFuns, actionCtreators) {
  const actonsMap = {};
  Object.keys(actionCtreators).forEach((item) => {
    if (typeof actionCtreators[item] === "function") {
      actonsMap[item] = actionCtreators[item];
    }
  });
  return (target) => {
    connect(stateFuns, (dispatch) => {
      const actionS = bindActionCreators(actonsMap, dispatch);
      return { ...actionS, dispatch };
    })(target);
  };
}
