import { combineReducers } from "redux";
import loginState from "../login/reduce";
// 组合reducer
const rootReducer = combineReducers({
  loginState,
});
export default rootReducer;
