import loggerMiddleware from "./logger";
import thunkMiddleware from "redux-thunk";
const middleWares = [loggerMiddleware, thunkMiddleware];
export default middleWares;
