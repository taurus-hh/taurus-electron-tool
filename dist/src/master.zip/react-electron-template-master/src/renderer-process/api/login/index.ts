import API from "../base";

interface Auth {
  key: string;
  password: string;
  type: string;
}
/**
 * @description: 登录获取token 和 机构列表
 * @msg:
 * @param {string} key 账号
 * @param {string} password 密码
 * @return {promise}
 */
export function appAuth(params: Auth) {
  return API.post("/auth", params)
    .then((res) => {
      return res.data;
    })
    .catch((error) => {
      console.log(error);
    });
}
