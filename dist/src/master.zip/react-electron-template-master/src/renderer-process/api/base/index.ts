import axios, { AxiosRequestConfig, AxiosInstance, AxiosResponse } from "axios";
import config from "@/configs";
import { getToken } from "@/utils";
import { resizeWindow } from "@/libs/ipc";
import { message } from "antd";
let unAuthFlag = true;
class AxiosService {
  $axios: AxiosInstance;
  constructor(config: AxiosRequestConfig) {
    const api = axios.create(config);
    api.interceptors.request.use(
      (config: AxiosRequestConfig) => {
        const token = getToken("token");
        if (token) {
          config.headers.Authorization = token;
        }
        return config;
      },
      (error) => {
        console.log("request err:", error);
        return Promise.reject(error);
      }
    );

    api.interceptors.response.use(
      (res: AxiosResponse) => {
        if (res.status === 400 || res.status === 500) {
          message.error(res.data.message);
        }
        if (res.status === 401 && unAuthFlag && res.config.url !== "/auth") {
          message.error(res.data.message);
          unAuthFlag = false;
          setTimeout(() => {
            window.location.hash = "/login";
            resizeWindow(340, 450);
          }, 1000);
        }
        if (res.status === 401 && res.config.url === "/auth") {
          message.error(res.data.message);
        }
        if (res.status === 200) {
          unAuthFlag = true;
          res.data.ok = res.data.status_code === 200;
        }
        return res;
      },
      (error) => {
        console.log("response err:", error.toJSON());
        message.error(error.toJSON().message);
        return Promise.reject(error);
      }
    );
    this.$axios = api;
  }

  get(url: string, params: any) {
    return this.$axios.get(url, {
      params,
    });
  }

  delete(url: string, params: any) {
    return this.$axios.delete(url, {
      params,
    });
  }

  head(url: string, params: any) {
    return this.$axios.head(url, {
      params,
    });
  }

  put(url: string, params: any) {
    return this.$axios.put(url, {
      params,
    });
  }

  post(url: string, params: any) {
    return this.$axios.post(url, params);
  }

  patch(url: string, params: any) {
    return this.$axios.patch(url, params);
  }
}

const configAPI = {
  timeout: 15000,
  baseURL: config.API[API_ENV],
  validateStatus: function () {
    return true;
  },
};

const API = new AxiosService(configAPI);
export default API;
