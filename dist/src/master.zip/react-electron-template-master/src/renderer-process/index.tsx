import * as React from "react";
import * as ReactDOM from "react-dom";
import { Provider } from "react-redux";
import { configStore } from "@/store/configStore";
import routes from "@/routes";
import App from "@/pages";
import "./style/global.css";
const store = configStore({});

const Main = () => {
  return (
    <Provider store={store}>
      <App routes={routes} />
    </Provider>
  );
};
ReactDOM.render(<Main />, document.getElementById("app"));
