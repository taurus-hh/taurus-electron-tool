import * as React from "react";
import BaseModal from "../../base/modal";
import "./index.less";
interface ModalProps {
  visible: boolean;
  children?: React.ReactNode;
  handleOk?: () => void;
  handleCancel?: () => void;
  close?: boolean;
}
const Modal: React.FC<ModalProps> = (props: ModalProps) => {
  const { handleCancel, close = true } = props;
  return (
    <BaseModal visible={props.visible}>
      <div className="lantern-modal-root">
        <div className="lantern-modal-mask"></div>
        <div className="lantern-modal-body">
          {close && (
            <span className="lantern-modal-close" onClick={handleCancel}>
              <svg
                className="icon"
                viewBox="0 0 1024 1024"
                version="1.1"
                xmlns="http://www.w3.org/2000/svg"
                p-id="10057"
                width="20"
                height="20"
              >
                <path
                  d="M809.984 765.7472L556.3904 512l253.696-253.7984a31.3856 31.3856 0 0 0-44.3392-44.288l-253.6448 253.6448L258.2528 214.016a31.3856 31.3856 0 0 0-44.288 44.288l253.7472 253.7984-253.7472 253.696a31.3856 31.3856 0 0 0 44.288 44.288l253.7984-253.7984 253.7472 253.7984a31.3856 31.3856 0 0 0 44.3392 0 31.488 31.488 0 0 0-0.1024-44.288"
                  p-id="10058"
                  fill="#979797"
                ></path>
              </svg>
            </span>
          )}
          {props.children}
        </div>
      </div>
    </BaseModal>
  );
};
export default Modal;
