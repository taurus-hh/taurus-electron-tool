import * as React from "react";
import { closeWindow, minizeWindow, maximizeWindow } from "@/libs/ipc";
import "./index.less";
const { useCallback } = React;

interface windowToolConfig {
  options: Array<{ name: string }>;
  gutter?: number;
}
interface eventNameFuncConfig {
  [propsName: string]: () => void;
}
const eventNameFunc: eventNameFuncConfig = {
  closeWindow,
  minizeWindow,
  maximizeWindow,
};
const windowTool: React.FC<windowToolConfig> = ({
  options,
  gutter = 9,
}: windowToolConfig) => {
  return (
    <div className="window-tool">
      {options.map((item, index) => {
        return (
          <span
            style={{ marginRight: gutter }}
            key={index}
            className={`window-tool-${item.name}`}
            onClick={useCallback(() => {
              eventNameFunc[`${item.name}Window`]();
            }, [])}
          ></span>
        );
      })}
    </div>
  );
};
export default windowTool;
