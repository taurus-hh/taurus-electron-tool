import * as React from "react";
import Input from "../input/index";
import "./index.less";

interface optionConfig {
  id: number;
  name: string;
  [propName: string]: any;
}
interface SelectConfig {
  options?: Array<optionConfig>;
  noFoundData?: string;
  onChange?: (value: optionConfig) => void;
  defaultValue?: string;
}
const { useState, useCallback, useMemo } = React;

const Select: React.FC<SelectConfig> = ({
  options = [],
  onChange,
  noFoundData = "暂无数据",
  defaultValue = "",
}: SelectConfig) => {
  const [isDisplay, setIsDisplay] = useState<boolean>(false);
  const optionMaps = useMemo(() => {
    const map: { [key: string]: any } = {};
    options.forEach((item) => {
      map[item.id] = item;
    });
    return map;
  }, [options]);
  const name = useMemo(() => {
    return optionMaps[defaultValue] ? optionMaps[defaultValue].name : "";
  }, []);
  const [selectedName, setSelectedName] = useState<string>(name);
  return (
    <div className="board-select">
      <div className="board-select-wrapper">
        <span
          onClick={useCallback(() => {
            setIsDisplay(true);
          }, [])}
        ></span>
        <Input
          placeholder={selectedName || "请选择"}
          type="text"
          onFocus={useCallback(() => {
            setIsDisplay(true);
          }, [])}
          onBlur={useCallback(() => {
            setIsDisplay(false);
          }, [])}
        />
        <div
          className="board-select-options"
          style={{ visibility: isDisplay ? "visible" : "hidden" }}
          onClick={useCallback((event: React.MouseEvent<HTMLDivElement>) => {
            const target = event.target as HTMLDivElement;
            const id = target.getAttribute("data-id");
            if (id && onChange) {
              onChange(optionMaps[id]);
              setSelectedName(optionMaps[id].name);
            }
          }, [])}
        >
          {options.map((item) => {
            return (
              <div
                className="board-select-options-item"
                key={item.id}
                data-id={item.id}
              >
                {item.name}
              </div>
            );
          })}
          {options.length === 0 && (
            <div className="board-select-options-nodata">{noFoundData}</div>
          )}
        </div>
      </div>
    </div>
  );
};
export default Select;
