import * as React from "react";
import "./input.less";

const { useCallback, useState, useMemo } = React;

interface InputConfig {
  placeholder?: string;
  onChange?: (value: string) => void;
  onFocus?: () => void;
  onBlur?: () => void;
  maxlength?: string;
  defaultValue?: string;
  type?: string;
  style?: { width: number };
  disabled?: boolean;
  value?: string;
  pattern?: null | RegExp;
}

interface InputNumberConfig extends InputConfig {
  min?: string;
  max?: string;
}

const InputNumberWidget: React.FC<InputNumberConfig> = ({
  placeholder,
  onChange,
  defaultValue = "",
  maxlength = "0",
  disabled = false,
}: InputNumberConfig) => {
  const [inputValue, setInputValue] = useState<string>(defaultValue);
  return (
    <input
      disabled={disabled}
      className="input-self"
      type="number"
      placeholder={placeholder}
      onKeyDown={useCallback((event: React.KeyboardEvent<HTMLInputElement>) => {
        if (
          event.keyCode === 190 ||
          event.keyCode === 189 ||
          event.keyCode === 69
        )
          event.preventDefault();
      }, [])}
      onChange={useCallback((event: React.ChangeEvent<HTMLInputElement>) => {
        let value = event.target.value.trim();
        if (Number(maxlength) > 0) {
          value = value.slice(0, Number(maxlength));
        }
        if (onChange) {
          onChange(value);
        }
        setInputValue(value);
      }, [])}
      value={inputValue}
    />
  );
};

const Input: React.FC<InputConfig> = ({
  placeholder,
  onChange,
  onFocus,
  onBlur,
  defaultValue = "",
  maxlength = "0",
  type = "text",
  style,
  disabled = false,
  value = "",
  pattern = null,
}: InputConfig) => {
  const [inputValue, setInputValue] = useState<string>();
  const defaultComputed = useMemo(() => value || defaultValue, [
    defaultValue,
    value,
  ]);
  return (
    <input
      className="input-self"
      disabled={disabled}
      style={style}
      type={type}
      placeholder={placeholder}
      onChange={useCallback((event: React.ChangeEvent<HTMLInputElement>) => {
        let value = event.target.value;
        if (pattern) {
          value = value.replace(pattern, "");
        }
        if (Number(maxlength) > 0) {
          value = value.slice(0, Number(maxlength));
        }
        if (onChange) {
          onChange(value);
        }
        setInputValue(value);
      }, [])}
      onFocus={useCallback(() => {
        if (onFocus) {
          onFocus();
        }
      }, [])}
      onBlur={useCallback(() => {
        if (onBlur) {
          onBlur();
        }
      }, [])}
      value={inputValue || defaultComputed}
    />
  );
};
export const InputNumber = React.memo(InputNumberWidget);
export default React.memo(Input);
