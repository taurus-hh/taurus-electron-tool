import * as React from "react";
import * as ReactDOM from "react-dom";
interface ModalProps {
  visible: boolean;
}
class Modal extends React.Component<ModalProps> {
  node: HTMLDivElement;
  constructor(props: ModalProps) {
    super(props);
    this.node = document.createElement("div");
  }

  componentDidMount() {
    document.body.appendChild(this.node);
  }

  componentWillUnmount() {
    document.body.removeChild(this.node);
  }
  render() {
    return this.props.visible
      ? ReactDOM.createPortal(this.props.children, this.node)
      : null;
  }
}
export default Modal;
