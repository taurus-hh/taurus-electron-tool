import { ipcRenderer } from "electron";

/**
 * @description: 关闭当前窗口
 * @param {*}
 */
export function closeWindow() {
  ipcRenderer.send("close-window");
}
/**
 * @description: 最小化当前窗口
 * @param {*}
 */
export function minizeWindow() {
  ipcRenderer.send("minize-window");
}
/**
 * @description: 最小化当前窗口
 * @param {*}
 */
export function maximizeWindow() {
  ipcRenderer.send("maximize-window");
}
/**
 * @description: 最小化当前窗口
 * @param {*}
 */
export function resizeWindow(width: number, height: number) {
  ipcRenderer.send("resize-window", { width, height });
}
/**
 * @description: 创建窗口
 * @param {*}
 */
export function createWindow(url: string, title: string) {
  ipcRenderer.send("new-window", { url, title });
}

export function getPath(name: string = "appData") {
  return ipcRenderer.sendSync("resource-dest", name);
}

export function unzip(path: string, dir: string) {
  ipcRenderer.send("unzip", { sourcePath: path, targetPath: dir });
}

/**
 * @description: 创建pdf窗口
 * @param {*}
 */
export function createPdfWindow(url: string, title: string) {
  ipcRenderer.send("pdf-window", { url, title });
}
/**
 * @description: 创建mp4窗口
 * @param {*}
 */
export function createMp4Window(url: string, title: string) {
  ipcRenderer.send("mp4-window", { url, title });
}
/**
 * @description: 创建mp3窗口
 * @param {*}
 */
export function createMp3Window(url: string, title: string) {
  ipcRenderer.send("mp3-window", { url, title });
}
/**
 * @description: 创建picture窗口
 * @param {*}
 */
export function createPictureWindow(url: string, title: string) {
  ipcRenderer.send("picture-window", { url, title });
}
export function createCoursewareWindow(
  coursewareId: string,
  dirId: string,
  token: string,
  title: string
) {
  ipcRenderer.send("courseware-window", {
    coursewareId,
    dirId,
    token,
    title,
  });
}
// 监听主进程信道回复
ipcRenderer.on("main-reply", (event, arg) => {
  console.log(arg);
});
