import low from "lowdb";
import FileSync from "lowdb/adapters/FileSync";
import fs from "fs-extra";
import { getPath } from "./ipc";
export class DiskDb {
  db: any;
  path: string;
  constructor() {
    this.db = null;
    this.path = getPath() + "/" + "appConfig.json";
    this.init();
  }
  init() {
    if (!this.db) {
      try {
        this.db = low(new FileSync(this.path));
      } catch (e) {
        if (fs.existsSync(this.path)) {
          fs.unlinkSync(this.path);
        }
        this.db = low(new FileSync(this.path));
      }
    }
  }
  addData(data: any) {
    this.db.defaults(data).write();
  }
  setValue(key: string, value: any) {
    this.db.set(key, value).write();
  }
  getValue(key: string) {
    return this.db.get(key).value();
  }
  removeData() {
    return this.db.setState();
  }
}

export const DiskDbCache = (function () {
  let singleton: DiskDb;
  return function () {
    if (!singleton) {
      singleton = new DiskDb();
    }
    return singleton;
  };
})();
