import fs from "fs-extra";
import { ipcRenderer } from "electron";
import { EventEmitter } from "events";
import { Downloader } from "./download";
import { getPath, unzip } from "@/libs/ipc";
import { DiskDbCache, DiskDb } from "./diskManage";

const dest = getPath() + "/downLoadZby";
class Resource extends EventEmitter {
  url: string;
  dest: string;
  isDelete: boolean;
  version: Version | null = null;
  versionNew: string = "";
  constructor(
    url: string,
    config: any = { hasVersion: false, isDelete: true }
  ) {
    super();
    const { hasVersion, dir, versionNew, isDelete } = config;
    this.url = url;
    if (hasVersion) {
      this.version = new Version(dir);
      this.versionNew = versionNew;
    }
    this.dest = dest;
    this.isDelete = isDelete || true;
    Downloader.mkDir(dest);
    this.addUnzipListener();
  }
  start() {
    const dl = new Downloader({
      url: this.url,
      destFolder: this.dest,
    });
    dl.start();
    // 监听
    dl.on("start", () => {
      this.emit("download.start");
    })
      .on("progress", (data) => {
        this.emit("download.progress", data);
      })
      .on("progress.speed", (data) => {
        this.emit("download.progress.speed", data);
      })
      .on("complete", ({ path, fileName }) => {
        this.emit("download.done", {
          fileName,
        });
        unzip(path, dest);
      });
  }
  addUnzipListener() {
    ipcRenderer.on("unzip.start", () => {
      this.unzipStart();
    });
    ipcRenderer.on("unzip.progress", (event, progress) => {
      this.unzipProgress(progress);
    });
    ipcRenderer.on("unzip.done", (event, result) => {
      this.unzipDone(result);
    });
  }

  unzipStart() {
    this.emit("unzip.start");
  }
  unzipProgress(progress: any) {
    this.emit("unzip.progress", progress);
  }
  unzipDone(result: any) {
    this.emit("unzip.done", result);
    if (this.version) {
      this.version.version = this.versionNew;
    }
    console.log(result, "ujkk");
    if (this.isDelete) {
      fs.remove(result.zipPath, function (err) {
        if (err) {
          console.log(err);
        }
      });
    }
  }
}

export function resourceDownLoad(url: string, config?: any) {
  return new Resource(url, config);
}
export class Version {
  versionDb: DiskDb;
  dir: string;
  constructor(dir: string) {
    this.versionDb = DiskDbCache();
    this.dir = dir;
  }
  get version() {
    return this.versionDb.getValue(this.dir);
  }
  set version(version: string) {
    this.versionDb.setValue(this.dir, version);
  }
}
export function resourceHelper(dir: string, version: string) {
  const caceVersion = new Version(dir).version;
  if (caceVersion === version) {
    const targetDest = dest + "/common_web/" + dir;
    if (!fs.existsSync(targetDest)) {
      console.log("Destination Folder is not exist " + targetDest);
      return false;
    }
    return true;
  } else {
    return false;
  }
}
export default {
  resourceDownLoad,
  resourceHelper,
};
