export default {
  API: {
    test: "xxxxxxxxxxxxxxxxxxxxxx",
  },
};
