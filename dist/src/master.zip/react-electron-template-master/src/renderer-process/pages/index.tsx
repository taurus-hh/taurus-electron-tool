import * as React from "react";
import { HashRouter, Route, Switch } from "react-router-dom";
import { routeInterface } from "@/routes";
const Router = HashRouter;

interface appProps {
  routes: Array<routeInterface>;
}

export default class App extends React.Component<appProps> {
  render() {
    const { routes } = this.props;
    return (
      <Router>
        <Switch>
          {routes.map((route, i) => (
            <RouteWithSubRoutes key={i} {...route} />
          ))}
        </Switch>
      </Router>
    );
  }
}

export function RouteWithSubRoutes(route: routeInterface) {
  return (
    <Route
      path={route.path}
      render={(props) => <route.component {...props} routes={route.routes} />}
    />
  );
}
