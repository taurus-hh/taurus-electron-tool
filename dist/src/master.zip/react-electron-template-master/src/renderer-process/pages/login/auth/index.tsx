import React from "react";
import classNames from "classnames";
import { message } from "antd";
import Input, { InputNumber } from "@/components/base/input";
import UpdateModal from "./update";
import "./login.less";

import { RouteComponentProps } from "react-router-dom";
import { appAuth } from "@/api";
import { _debounce, setUserInfo } from "@/utils";
import { useLogin, LOGIN_INSLIST } from "../use-login";
const pkg = require("../../../../../package.json");
const headImage = require("@/assets/images/defaulthead.png");
const { useCallback, useState, useRef, useLayoutEffect } = React;

/**
 * @description: 登录组件 账号 密码
 * @msg: 账号 11位 密码6-20位
 * @param {Object} 组件的props
 * @return {*} JSX Element
 */
const Login: React.FC<RouteComponentProps> = (): any => {
  const [account, setAccount] = useState<string>("");
  const [password, setPassword] = useState<string>("");
  const LoginRef = useRef<{ key: string; password: string } | null>(null);
  useLayoutEffect(() => {
    LoginRef.current = {
      key: account,
      password,
    };
  });

  const changeAccount = useCallback((value) => {
    setAccount(value);
  }, []);

  const changePassword = useCallback((value) => {
    setPassword(value);
  }, []);
  const dispatch = useLogin();
  // 登录(防止连续点击)
  const onConfirm = useCallback(
    _debounce(async () => {
      if (LoginRef.current) {
        const { password } = LoginRef.current;
        if (password.length < 6 || password.length > 20) {
          message.warn("请将密码设置在6-20位");
          return false;
        }
        const authRes = await appAuth({
          ...LoginRef.current,
          type: "9",
        });
        if (authRes?.ok && authRes.data) {
          const insList = authRes.data.users.map((item: any) => {
            return {
              id: item.id,
              name: item.school.name,
              token: authRes.data.token,
            };
          });
          setUserInfo("insList", insList);
          if (dispatch) {
            dispatch({ type: LOGIN_INSLIST, payload: insList });
          }
        }
      }
    }, 200),
    [LoginRef]
  );
  // 组合样式
  const confirmClass = classNames("login_confirm", {
    "login_confirm--active": account && password,
  });
  return (
    <div className="login">
      <div className="login_title">
        学习强国{pkg.version}
        {API_ENV === "staging" ? "-beta" : ""}
      </div>
      <div className="login_avatar">
        <img src={headImage} alt="" />
        <div>学习强国</div>
      </div>
      <div className="login_account">
        <InputNumber
          placeholder="请输入账号"
          onChange={changeAccount}
          maxlength={"11"}
        />
      </div>
      <div className="login_password">
        <Input
          type="password"
          placeholder="请输入密码"
          onChange={changePassword}
        />
      </div>
      <div className={confirmClass} onClick={onConfirm}>
        登录
      </div>
      <UpdateModal />
    </div>
  );
};
export default Login;
