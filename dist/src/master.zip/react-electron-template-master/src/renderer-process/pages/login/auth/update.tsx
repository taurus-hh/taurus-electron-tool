import * as React from "react";
import Modal from "@/components/base/modal";
import { ipcRenderer } from "electron";
import "./update.less";
const { useState, useCallback, useEffect } = React;

const UpdateModal: React.FC = () => {
  const [visible, setVisible] = useState(false);
  const [text, setText] = useState("检测到新版本，正在更新");
  const [progress, setProgress] = useState(0);
  const handleCancel = useCallback(() => {
    ipcRenderer.send("update-cancel");
    setVisible(false);
  }, []);
  useEffect(() => {
    ipcRenderer.send("update-start");
    ipcRenderer.on("update-message", (e, text: string) => {
      console.log(text);
      if (text === "检测到新版本，正在更新") {
        setVisible(true);
        setText(text);
      }
    });
    ipcRenderer.on("update-error", () => {
      setText("更新出错");
    });
    // setVisible(true);
    ipcRenderer.on("downloadProgress", (e, percent: number) => {
      setProgress(percent);
    });
    ipcRenderer.on("update-finished", () => {
      setVisible(false);
      ipcRenderer.send("update-finished");
    });
  }, []);
  return (
    <Modal visible={visible}>
      <div className="update-modal-root">
        <div className="update-modal-mask"></div>
        <div className="update-modal-body">
          {
            <span className="update-modal-close" onClick={handleCancel}>
              <svg
                className="icon"
                viewBox="0 0 1024 1024"
                version="1.1"
                xmlns="http://www.w3.org/2000/svg"
                p-id="10057"
                width="20"
                height="20"
              >
                <path
                  d="M809.984 765.7472L556.3904 512l253.696-253.7984a31.3856 31.3856 0 0 0-44.3392-44.288l-253.6448 253.6448L258.2528 214.016a31.3856 31.3856 0 0 0-44.288 44.288l253.7472 253.7984-253.7472 253.696a31.3856 31.3856 0 0 0 44.288 44.288l253.7984-253.7984 253.7472 253.7984a31.3856 31.3856 0 0 0 44.3392 0 31.488 31.488 0 0 0-0.1024-44.288"
                  p-id="10058"
                  fill="#979797"
                ></path>
              </svg>
            </span>
          }
          <div className="update-modal-title">{text}</div>
          <div className="update-modal-progress">
            <progress value={Math.floor(progress)} max="100"></progress>
            <span>{Math.floor(progress)}%</span>
          </div>
        </div>
      </div>
    </Modal>
  );
};
export default React.memo(UpdateModal);
