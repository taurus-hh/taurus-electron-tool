import { createContext, useContext, Dispatch } from "react";
// 定义action类型常量
export const LOGIN_INSLIST = "LOGIN/INSLIST";
export const LOGIN_TOKEN = "LOGIN/TOKEN";

interface initialStateConfig {
  insList: any[];
  token: string;
}
export const initialState: initialStateConfig = { insList: [], token: "" };

type ACTIONTYPE =
  | { type: "LOGIN/INSLIST"; payload: any[] }
  | { type: "LOGIN/TOKEN"; payload: string };

export function loginReducer(
  state: initialStateConfig,
  action: ACTIONTYPE
): initialStateConfig {
  switch (action.type) {
    case "LOGIN/INSLIST":
      return {
        ...state,
        insList: action.payload,
      };
    case "LOGIN/TOKEN":
      return {
        ...state,
        token: action.payload,
      };
    default:
      throw new Error();
  }
}

export const LoginContext = createContext<Dispatch<ACTIONTYPE> | null>(null);

export const useLogin = () => {
  const dispatch = useContext(LoginContext);
  return dispatch;
};
