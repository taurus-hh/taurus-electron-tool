import React from "react";
import { RouteComponentProps, Switch, Route } from "react-router-dom";
import WindowTool from "@/components/container/window-tool";
import { LoginContext, initialState, loginReducer } from "./use-login";
import "./index.less";
const { useReducer } = React;
interface LoginProp extends RouteComponentProps {
  routes: Array<any>;
}
const options = [{ name: "minize" }, { name: "close" }];
const LoginRoot: React.FC<LoginProp> = ({ routes }: LoginProp) => {
  const [state, dispatch] = useReducer(loginReducer, initialState);
  return (
    <div className="root">
      <div className="root-window--tool">
        <WindowTool options={options} />
      </div>
      <LoginContext.Provider value={dispatch}>
        <Switch>
          {routes.map((route, index) => {
            return (
              <Route
                path={route.path}
                key={index}
                exact={route.exact}
                render={(props) => (
                  <route.component {...props} insList={state.insList} />
                )}
              />
            );
          })}
        </Switch>
      </LoginContext.Provider>
    </div>
  );
};
export default LoginRoot;
