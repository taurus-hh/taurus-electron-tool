/*
 * @Descripttion: 简易的国际化方案 方便后期更改
 ******** 建议使用npm上的国际化方案包
 * @version: 1.0.0
 * @Author: yangzhenxiu
 * @Date: 2020-12-07 13:54:48
 * @LastEditors: Please set LastEditors
 * @LastEditTime: 2020-12-07 14:45:41
 */
import zh from "./zh";
import en from "./en";

interface messageConfig {
  [key: string]: any;
}

interface lanConfig {
  lan: string;
  message: messageConfig;
}

const config: lanConfig = {
  lan: "zh",
  message: {
    zh: zh,
    en: en,
  },
};

export function changeLocal(local: string) {
  config["lan"] = local;
}

export default function in18(key: string) {
  const lan = config["lan"];
  return config["message"][lan][key];
}
