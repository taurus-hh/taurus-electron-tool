type zhInterface = {
  [key: string]: string;
};

const zh: zhInterface = {
  title: "魔法黑板",
  login: "登录",
  forget: "忘记密码",
  input_accunt: "请输入账号",
  input_code: "请输入验证码",
  get_code: "获取验证码",
  back: "返回",
  set_new: "设置新密码",
  confirm: "确定",
  new_password: "新密码",
  again: "确认密码",
  limit_password: "请输入6-20位密码",
  select_intus: "选择机构",
  select_placeholder: "请选择",
};
export default zh;
