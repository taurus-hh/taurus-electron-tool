const _toString = Array.prototype.toString;

export function isUndefined(val: any) {
  return typeof val === "undefined";
}

export function isDate(val: any) {
  return _toString.call(val) === "[object Date]";
}

export function isFile(val: any) {
  return _toString.call(val) === "[object File]";
}

export function isBlob(val: any) {
  return _toString.call(val) === "[object Blob]";
}

export function isString(val: any) {
  return typeof val === "string";
}

export function isNumber(val: any) {
  return typeof val === "number";
}
export function hasOwn(obj: object, key: string) {
  return Object.prototype.hasOwnProperty.call(obj, key);
}
