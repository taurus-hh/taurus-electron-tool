const FUNC_ERROR_TEXT = "Expected a function";
type AnyFunction = (...args: Array<any>) => void;

/**
 * @description: 防抖 用户动作停止后延迟wait ms再执行回调
 * @msg:
 * @param {function} func debounce的函数
 * @param {number} wait 规定的时间内执行
 * @return {Function}
 */
export function _debounce(func: AnyFunction, wait: number = 0) {
  if (typeof func !== "function") {
    throw new TypeError(FUNC_ERROR_TEXT);
  }
  let timeId: any;
  return function (...rest: any[]) {
    clearTimeout(timeId);
    timeId = setTimeout(() => {
      func.apply(this, rest);
    }, wait);
  };
}

/**
 * @description: 节流 用户动作 每次在规定的wait时间内执行一次
 * @msg:
 * @param {function} func _throttle的函数
 * @param {number} wait 规定的时间
 * @return {Function}
 */
export function _throttle(func: AnyFunction, wait: number = 0) {
  if (typeof func !== "function") {
    throw new TypeError(FUNC_ERROR_TEXT);
  }
  let pre = Date.now();
  return function (...rest: any[]) {
    const now = Date.now();
    if (now - pre > wait) {
      pre = now;
      func.apply(this, rest);
    }
  };
}

export function getUrlParamas(search: string) {
  const reg = new RegExp("(^|&)" + search + "=(.*)");
  const r = window.location.search.substr(1).match(reg);
  return r ? decodeURIComponent(r[2]) : "";
}

/**
 * @description: 获取文件后缀ext
 * @msg:
 * @param {string} name
 * @return {string} .ppt....
 */
export function getFileNameSuffix(name: string) {
  return name.slice(name.lastIndexOf("."));
}

export function getMimeType(name: string) {
  const suffix = getFileNameSuffix(name);
  switch (suffix) {
    case ".ppt":
    case ".pptx":
      return 5;
    case ".docx":
    case ".doc":
      return 4;
    case ".xls":
    case ".xlsx":
      return 6;
    case ".pdf":
      return 3;
    case ".mp3":
      return 7;
    case ".mp4":
      return 8;
    case ".jpg":
    case ".jpeg":
    case ".png":
    case ".gif":
      return 9;
    default:
      return 5;
  }
}
