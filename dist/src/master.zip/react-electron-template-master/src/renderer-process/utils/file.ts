import fs from "fs-extra";
export async function copyFiles() {
  try {
    await fs.copy("/tmp/myfile", "/tmp/mynewfile");
  } catch (err) {
    console.error(err);
  }
}
