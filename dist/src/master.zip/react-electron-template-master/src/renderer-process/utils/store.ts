/**
 * @description: 登录认证token本地存储
 * @param {string} key
 * @param {string} token
 * @return {*}
 */
export function setToken(key: string, token: string) {
  localStorage.setItem(key, token);
}

/**
 * @description: 登录认证token本地存储
 * @param {string} key
 * @return {string} token
 */
export function getToken(key: string) {
  return localStorage.getItem(key);
}

/**
 * @description: userinfo本地存储
 * @param {string} key
 * @return {object} user
 */
export function setUserInfo(key: string, user: object) {
  localStorage.setItem(key, JSON.stringify(user));
}

/**
 * @description: 登录认证token本地存储
 * @param {string} key
 * @return {object} user
 */
export function getUserInfo(key: string) {
  return JSON.parse(localStorage.getItem(key) as string);
}
