import React from "react";
// 登录页面
import LoginRoot from "@/pages/login";
import Login from "@/pages/login/auth";
export interface routeInterface {
  path: string;
  component: React.FC<any> | React.ComponentClass;
  routes?: Array<routeInterface>;
  exact?: boolean;
}

const routes: Array<routeInterface> = [
  {
    path: "/login",
    component: LoginRoot,
    routes: [
      {
        path: "/login/",
        component: Login,
        exact: true,
      },
    ],
  },
];
export default routes;
