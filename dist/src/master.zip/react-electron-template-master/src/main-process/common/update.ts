import { autoUpdater, CancellationToken } from "electron-updater";
import log from "./log";
const pkg = require("../../../package.json");
import { ipcMain } from "electron";

export function updateHandle(mainWindow: Electron.BrowserWindow) {
  const cancellationToken = new CancellationToken();
  autoUpdater.logger = log;
  autoUpdater.currentVersion = pkg.version;
  autoUpdater.on("error", function (error) {
    if (error) {
      console.log(error, "error");
      mainWindow.webContents.send("update-error", "检查更新出错");
    }
  });
  // 有资源更新
  autoUpdater.on("update-available", (info) => {
    console.log(info);
    mainWindow.webContents.send("update-message", "检测到新版本，正在更新");
  });
  // 有资源已是最新
  autoUpdater.on("update-not-available", (info) => {
    console.log(info);
    mainWindow.webContents.send("update-message", "已是最新版本");
  });
  // 下载过程
  autoUpdater.on("download-progress", (progressObj) => {
    console.log(progressObj);
    mainWindow.webContents.send("downloadProgress", progressObj.percent);
  });
  // 下载完成
  autoUpdater.on("update-downloaded", () => {
    ipcMain.on("update-finished", () => {
      autoUpdater.quitAndInstall();
    });
    mainWindow.webContents.send("update-finished");
  });
  // 取消，设置无用url
  ipcMain.on("update-cancel", () => {
    autoUpdater.setFeedURL("http://www.mofaxiao.com");
    cancellationToken.cancel();
  });
  // 取消，设置无用url
  ipcMain.on("update-start", () => {
    autoUpdater.checkForUpdates().then((result) => {
      console.log(result);
    });
  });
}
