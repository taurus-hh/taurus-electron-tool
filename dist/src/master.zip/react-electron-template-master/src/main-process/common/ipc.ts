import { ipcMain, app } from "electron";
import {
  createSubWindow,
  createPdfWindow,
  createMp4Window,
  createMp3Window,
  createPictureWindow,
  createCoursewareWindow,
} from "./createSubWindow";
export function addIpcMainListener(win: any) {
  ipcMain.on("close-window", (event) => {
    event.reply("main-reply", { type: "close-window", done: true });
    win.destroy();
  });
  ipcMain.on("minize-window", (event) => {
    event.reply("main-reply", { type: "minize-window", done: true });
    // process.crash();
    win.minimize();
  });
  ipcMain.on("resize-window", (event, arg) => {
    const { width, height } = arg;
    event.reply("main-reply", { type: "resize-window", done: true });
    console.log(width, height);
    win.unmaximize();
    win.center();
  });
  ipcMain.on("maximize-window", (event) => {
    event.reply("main-reply", { type: "maximize-window", done: true });
    win.maximize();
  });
  ipcMain.on("new-window", (event, arg) => {
    const { url, title } = arg;
    event.reply("main-reply", { type: "new-window", done: true });
    createSubWindow(url, title);
  });
  ipcMain.on("pdf-window", (event, arg) => {
    const { url, title } = arg;
    event.reply("main-reply", { type: "pdf-window", done: true });
    createPdfWindow(url, title);
  });
  ipcMain.on("mp4-window", (event, arg) => {
    const { url, title } = arg;
    event.reply("main-reply", { type: "mp4-window", done: true });
    createMp4Window(url, title);
  });
  ipcMain.on("mp3-window", (event, arg) => {
    const { url, title } = arg;
    event.reply("main-reply", { type: "mp3-window", done: true });
    createMp3Window(url, title);
  });
  ipcMain.on("picture-window", (event, arg) => {
    const { url, title } = arg;
    event.reply("main-reply", { type: "picture-window", done: true });
    createPictureWindow(url, title);
  });
  ipcMain.on("resource-dest", (event, name) => {
    event.returnValue = app.getPath(name);
  });
  ipcMain.on("courseware-window", (event, args) => {
    const { coursewareId, dirId, title, token } = args;
    event.reply("main-reply", { type: "ourseware-window", done: true });
    createCoursewareWindow(coursewareId, dirId, token, title);
  });
}
