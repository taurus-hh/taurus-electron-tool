import SensorsAnalytics from "sa-sdk-node";
import * as os from "os";
const pkg = require("../../../package.json");
const sa = new SensorsAnalytics();
sa.disableReNameOption();
sa.submitTo("http://sensorsdata-4.talbrain.com:8106/sa?project=weclassroom");
sa.registerSuperProperties({
  version: pkg.version,
  $env: API_ENV,
  clienttype: os.platform() === "darwin" ? "mac" : "win",
});
export default sa;
