import log from "electron-log";
log.transports.file.level = "info";
log.transports.console.level = "silly";
export default log;
// log 日志文件目录
// 日志级别 error, warn, info, verbose, debug, silly
// file 文件日志
// console 控制台日志
// on Linux: ~/.config/{app name}/logs/{process type}.log
// on macOS: ~/Library/Logs/{app name}/{process type}.log
// on Windows: %USERPROFILE%\AppData\Roaming\{app name}\logs\{process type}.log
