import AutoLaunch from "auto-launch";
import { app } from "electron";
export function autoLaunch() {
  const minecraftAutoLauncher = new AutoLaunch({
    name: "电子黑板",
    path: process.execPath,
  });
  minecraftAutoLauncher.enable();
  minecraftAutoLauncher
    .isEnabled()
    .then((isEnabled: boolean) => {
      if (isEnabled) {
        return;
      }
      minecraftAutoLauncher.enable();
    })
    .catch((err: any) => {
      console.log(err);
    });
}

export function singleLaunch(mainWindow: Electron.BrowserWindow) {
  const gotTheLock = app.requestSingleInstanceLock();
  if (!gotTheLock) {
    app.quit();
    return;
  } else {
    app.on("second-instance", () => {
      if (mainWindow) {
        if (mainWindow.isMinimized()) mainWindow.restore();
        mainWindow.focus();
      }
    });
  }
}
