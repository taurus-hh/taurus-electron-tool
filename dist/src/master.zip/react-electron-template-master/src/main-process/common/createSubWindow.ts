import { BrowserWindow, screen, Menu } from "electron";
/**
 * @description: 预览讲义、试卷
 * @msg:
 * @param {string} url 资源的url
 * @param {string} title 课件名称
 * @return {*}
 */
export function createSubWindow(url: string, title: string) {
  const { width, height } = screen.getPrimaryDisplay().size;
  Menu.setApplicationMenu(null);
  const win = new BrowserWindow({
    width,
    height,
    webPreferences: {
      devTools: process.env.API_ENV === "staging",
    },
  });
  win.loadURL(url);
  win.once("ready-to-show", () => {
    win.show();
    win.setTitle(title);
  });
}
/**
 * @description: 预览pdf资源
 * @msg:
 * @param {string} url 资源的url
 * @param {string} title 课件名称
 * @return {*}
 */
export function createPdfWindow(url: string, title: string) {
  const { width, height } = screen.getPrimaryDisplay().size;
  Menu.setApplicationMenu(null);
  const win = new BrowserWindow({
    width,
    height,
    webPreferences: {
      devTools: process.env.API_ENV === "staging",
    },
  });
  const pdfUrl =
    process.env.NODE_ENV === "development"
      ? `http://localhost:8081/pdfjs/web/viewer.html?file=${url}`
      : `file://${__dirname}/static/pdfjs/web/viewer.html?file=${url}`;
  win.loadURL(pdfUrl);
  win.once("ready-to-show", () => {
    win.show();
    win.setTitle(title);
  });
}
/**
 * @description: 预览MP4资源
 * @msg:
 * @param {string} url 资源的url
 * @param {string} title 课件名称
 * @return {*}
 */
export function createMp4Window(url: string, title: string) {
  const { width, height } = screen.getPrimaryDisplay().size;
  Menu.setApplicationMenu(null);
  const win = new BrowserWindow({
    width,
    height,
    webPreferences: {
      devTools: process.env.API_ENV === "staging",
      nodeIntegration: true,
    },
  });
  const videoUrl =
    process.env.NODE_ENV === "development"
      ? `http://localhost:8081?file=${url}#/preview-video`
      : `file://${__dirname}/index.html?file=${url}#/preview-video`;
  win.loadURL(videoUrl);
  win.once("ready-to-show", () => {
    win.show();
    win.setTitle(title);
  });
}
/**
 * @description: 预览MP3资源
 * @msg:
 * @param {string} url 资源的url
 * @param {string} title 课件名称
 * @return {*}
 */
export function createMp3Window(url: string, title: string) {
  Menu.setApplicationMenu(null);
  const win = new BrowserWindow({
    width: 500,
    height: 300,
    webPreferences: {
      devTools: process.env.API_ENV === "staging",
    },
  });
  win.loadURL(url);
  win.once("ready-to-show", () => {
    win.show();
    win.setTitle(title);
  });
  win.on("closed", () => {
    win.destroy();
  });
}
/**
 * @description: 预览图片资源
 * @msg:
 * @param {string} url 资源的url
 * @param {string} title 课件名称
 * @return {*}
 */
export function createPictureWindow(url: string, title: string) {
  Menu.setApplicationMenu(null);
  const win = new BrowserWindow({
    width: 1100,
    height: 800,
    webPreferences: {
      devTools: process.env.API_ENV === "staging",
    },
  });
  win.loadURL(url);
  win.once("ready-to-show", () => {
    win.show();
    win.setTitle(title);
  });
  win.on("closed", () => {
    win.destroy();
  });
}
/**
 * @description: 教研云课件授课
 * @msg:
 * @param {string} coursewareId 课件的id
 * @param {string} dirId 课件压缩包 id
 * @param {string} token 登录token
 * @param {string} fileName 课件名称
 * @return {*}
 */
export function createCoursewareWindow(
  coursewareId: string,
  dirId: string,
  token: string,
  title: string
) {
  const { width, height } = screen.getPrimaryDisplay().size;
  Menu.setApplicationMenu(null);
  const win = new BrowserWindow({
    width,
    height,
    frame: false,
    webPreferences: {
      devTools: process.env.API_ENV === "staging",
      nodeIntegration: true,
      enableRemoteModule: true,
    },
  });
  const url =
    API_ENV === "staging"
      ? `https://tool-stage.mofaxiao.com?coursewareId=${coursewareId}&dirId=${dirId}&token=${token}&name=${title}#/`
      : `https://tool.mofaxiao.com?coursewareId=${coursewareId}&dirId=${dirId}&token=${token}&name=${title}#/`;
  win.loadURL(url);
  win.once("ready-to-show", () => {
    win.show();
    win.setTitle(title);
  });
}
