import kill from "kill-port";
import { autoLaunch, singleLaunch } from "../common/lauch";
import { updateHandle } from "../common/update";
import { addIpcMainListener } from "../common";
import { startUnzip, stopUnzip } from "../unzip";
import { startServer } from "../static-service";

import log from "../common/log";
import sa from "../common/sensor-node";
export default class Main {
  static mainWindow: Electron.BrowserWindow | null;
  static application: Electron.App;
  static BrowserWindow: typeof Electron.BrowserWindow;
  static DEV_TOOLS: Array<string> = ["REDUX_DEVTOOLS", "REACT_DEVELOPER_TOOLS"];

  /**
   * @description: 即时所有窗口关闭 OSX系统扔存在缓存
   * @msg:
   */
  private static onWindowAllClosed() {
    if (process.platform !== "darwin") {
      Main.application.quit();
      stopUnzip();
    }
  }
  /**
   * @description: 关闭窗口后 防止内存泄露
   * @msg:
   */
  private static onClosed() {
    Main.mainWindow = null;
    stopUnzip();
    Main.application.quit();
  }
  /**
   * @description: 注册插件函数 redux-tools等
   * @msg:
   */
  private static async installExtensions(devTool: string) {
    const installExtension = require("electron-devtools-installer");
    try {
      const installed = await installExtension.default(
        installExtension[devTool]
      );
      console.log(`Added Extension:  ${installed}`);
    } catch (error) {
      console.log("An error occurred: ", error);
    }
  }
  /**
   * @description:
   * On macOS it's common to re-create a window in the app when the
   * dock icon is clicked and there are no other windows open.
   */
  private static async activate() {
    if (Main.mainWindow === null) Main.createWindow();
  }
  /**
   * @description: 主窗口创建
   */
  private static async createWindow() {
    // if (process.env.NODE_ENV === "development") {
    //   for (const name of Main.DEV_TOOLS) {
    //     await Main.installExtensions(name);
    //   }
    // }
    Main.mainWindow = new Main.BrowserWindow({
      width: 340,
      height: 450,
      frame: false,
      // resizable: false,
      minimizable: true,
      maximizable: false,
      title: "电子黑板",
      webPreferences: {
        devTools: process.env.API_ENV === "staging",
        nodeIntegration: true,
        // preload: __dirname +"/preload.js",
      },
    });
    if (Main.mainWindow) {
      const URL =
        process.env.NODE_ENV === "development"
          ? `http://localhost:8081?#/login`
          : `file://${__dirname}/index.html?#/login`;
      Main.mainWindow.loadURL(URL);
      addIpcMainListener(Main.mainWindow);
      singleLaunch(Main.mainWindow);
      autoLaunch();
      updateHandle(Main.mainWindow);
      try {
        await kill(25272, "tcp");
      } catch (error) {
        console.log(error);
      } finally {
        startUnzip();
        startServer(Main.application.getPath("appData"));
      }
      Main.mainWindow.on("closed", Main.onClosed);
      Main.mainWindow.webContents.on(
        "render-process-gone",
        (event, details) => {
          log.error(URL + "\n" + details.reason);
          sa.track("crash", {
            id: 123456,
            reason: details.reason,
          });
        }
      );
    }
  }
  /**
   * @description: 主窗口创建入口
   */
  static main(app: Electron.App, browserWindow: typeof Electron.BrowserWindow) {
    Main.BrowserWindow = browserWindow;
    Main.application = app;
    Main.application.on("window-all-closed", Main.onWindowAllClosed);
    Main.application.on("ready", Main.createWindow);
    Main.application.on("activate", Main.activate);
    process.on("uncaughtException", function (err) {
      sa.track("crash", {
        id: 123456,
      });
      log.error(err + "\n" + err.stack);
      Main.application.exit(0);
    });
  }
}
