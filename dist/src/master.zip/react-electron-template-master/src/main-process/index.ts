import { app, BrowserWindow, crashReporter } from "electron";
import Main from "./main";
if (process.env.API_ENV !== "production") {
  // 启用devTools
  require("electron-debug")({ showDevTools: true, isEnabled: true });
}
Main.main(app, BrowserWindow);
crashReporter.start({
  submitURL: "http://localhost:9066/login",
  compress: true,
});
