import http from "http";
import serveStatic from "serve-static";
import finalhandler from "finalhandler";
const port = 25272;
const dirs = ["/downLoadZby"];
const handles: any[] = [];
let server;

function multiServe(
  req: http.IncomingMessage,
  res: http.ServerResponse,
  handles: any[],
  index: number,
  final: Function
) {
  const currentHandle = handles[index];
  if (currentHandle) {
    return currentHandle(req, res, () => {
      multiServe(req, res, handles, index + 1, final);
    });
  }
  return final(req, res)();
}
export function startServer(prefix: string) {
  for (const dir of dirs) {
    const staticPath = prefix + dir;
    handles.push(serveStatic(staticPath));
  }
  server = http.createServer((req, res) => {
    multiServe(req, res, handles, 0, finalhandler);
  });
  server.listen(port, () => {
    console.log(port, "port-----port");
  });
}
