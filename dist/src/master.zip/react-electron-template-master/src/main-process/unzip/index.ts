import { ipcMain } from "electron";
import { fork, ChildProcess } from "child_process";
import path from "path";
let child: ChildProcess;
interface msgConfig {
  type: string;
  data: Object;
  taskId: number;
}
const schedule = new Map();
function runUnzipProcess() {
  child = fork(path.join(__dirname, "unzip.js"));
  child.on("message", (msg: msgConfig) => {
    switch (msg.type) {
      case "unzip.start":
        schedule.get(msg.taskId)("unzip.start");
        break;
      case "unzip.progress":
        schedule.get(msg.taskId)("unzip.progress", msg.data);
        break;
      case "unzip.done":
        schedule.get(msg.taskId)("unzip.done", msg.data);
        break;
      case "unzip.error":
        schedule.delete(msg.taskId);
        break;
      case "uncaughtException":
      case "unhandledRejection":
        schedule.delete(msg.taskId);
        break;
    }
  });
}

function addEventListerners() {
  ipcMain.on("unzip", (event, args) => {
    const { sourcePath, targetPath, taskId } = args;
    if (!schedule.has(taskId)) {
      schedule.set(taskId, event.reply);
    }
    child.send({
      type: "unzip",
      data: { sourcePath, targetPath, taskId },
    });
  });
}

/**
 * @description: 启动解压子进程
 * @msg:
 * @param {*}
 * @return {*}
 */
export function startUnzip() {
  runUnzipProcess();
  addEventListerners();
}
export function stopUnzip() {
  if (child && !child.killed) {
    child.kill();
  }
}
