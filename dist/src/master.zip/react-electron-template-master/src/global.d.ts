declare const API_ENV: "test" | "staging" | "prerelease" | "production";
